package com.example.jpa_h2_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaH2DemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaH2DemoApplication.class, args);
	}

}
