package com.example.jpa_h2_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaH2DemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
